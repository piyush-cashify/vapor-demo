//
//  ThirdViewController.h
//  ThemeApplication
//
//  Created by Jitendra Deore on 29/08/18.
//  Copyright © 2018 Jitendra Deore. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirdViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *subTitleLabel;

@end
